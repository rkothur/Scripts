#!/bin/bash
export ANSIBLE_INVENTORY=/home/ec2-user/ram/emr-scripts/ansible_hosts

#to Avoid adding the hosts to known hosts
export ANSIBLE_HOST_KEY_CHECKING=False

export ANSIBLE_ROLES_PATH=/home/ec2-user/ram/emr-scripts/playbooks/roles

usage_help(){
        echo "Usage: for this script"
        echo "####### Get Help Usage#########"
        echo "     "
        echo "emr-services.sh --help or -h or -help or help"
        echo "     "
        echo "####### List of Available Tags to Run #########"
        echo "     "
        echo "emr-services.sh --list-tags"
        echo "     "
        echo "####### Listing all Tasks for all Plays/all tags #########"
        echo "     "
        echo "emr-services.sh --list-tasks"
        echo "     "
        echo "####### Actual Install Run for Given Tags #########"
        echo "     "
        echo "emr-services.sh tagname1,tagname2,...,tagnamen"
        echo "     "
        exit 0
}

if [ $# -eq 0 ] || [ $1 == "--help" ] || [ $1 == "help" ] || [ $1 == "-h" ] || [ $1 == "-help" ]
then
        usage_help
fi

        if [ $1 == "--list-tags" ];then
                echo "##########################################################################"
                echo "################### List of Available Tags to Run ########################"
                echo "##########################################################################"
                ansible-playbook playbooks/emr-services.yml --list-tags 
                exit 0
        elif [ $1 == "--list-tasks" ];then
                echo "##########################################################################"
                echo "########## Listing all Tasks for all Plays/all tags     ##################"
                echo "##########################################################################"
                ansible-playbook playbooks/emr-services.yml --list-tasks
                exit 0
	else 
		echo "##########################################################################"
                echo "########### Actual Install Run for Given Tags ############################"
                echo "##########################################################################"
                ansible-playbook playbooks/emr-services.yml --tags $1

	fi
